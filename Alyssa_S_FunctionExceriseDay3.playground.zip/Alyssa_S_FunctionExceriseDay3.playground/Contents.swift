import UIKit


struct Engine {
    var Engine1 = "v4"
    var Engine2 = "v6"
    var Engine3 = "v8"
}

let myEngine = Engine()

print("your can chose \(myEngine.Engine1) or \(myEngine.Engine2) or \(myEngine.Engine3)")
